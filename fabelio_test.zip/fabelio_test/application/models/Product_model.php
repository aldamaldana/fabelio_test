<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Product_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	function getTable($table_name, $filter, $order)
	{
		if($filter){
			$this->db->where($filter);
		}
		if($order){
			$this->db->order_by($order);
		}
		$sql = $this->db->get($table_name);
		return $sql;
	}

	function insert_data($data)
	{
		$this->db->insert('tbl_product', $data);
	}

	function insert_komentar($data)
	{
		$this->db->insert('tbl_komentar_product', $data);
	}

	function update($id_product, $data)
	{
		$this->db->where('id_product', $id_product);
		$this->db->update('tbl_product', $data);
	}

	function update_komentar($data, $id_komentar, $id_product)
	{
		$this->db->where('id_komentar', $id_komentar);
		$this->db->where('id_product', $id_product);
		$this->db->update('tbl_komentar_product', $data);
	}

	function getCountVote($id_product)
	{
		$this->db->select('up_vote, down_vote');
		$this->db->where('id_product', $id_product);
		$sql = $this->db->get('tbl_product');
		return $sql;
	}

	function getCountVoteKomentar($id_komentar, $id_product)
	{
		$this->db->select('up_vote, down_vote');
		$this->db->where('id_komentar', $id_komentar);
		$this->db->where('id_product', $id_product);
		$sql = $this->db->get('tbl_komentar_product');
		return $sql;
	}
}