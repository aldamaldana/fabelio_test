<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Product extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url'));
		$this->load->library(array('table'));
		$this->load->model('product_model');
	}

	function index()
	{
		$key = $this->input->post('pencarian');
		if($key != "")
		{
			$where = " nama_product LIKE '%$key%'";
		}
		else
		{
			$where = "";
		}
		$data['sql'] = $this->product_model->getTable('tbl_product', "$where", "");
		$this->load->view('product/index', $data);
	}

	function detail($id)
	{
		$data['sql'] = $this->product_model->getTable('tbl_product', "(id_product='$id')", "");
		$data['sql_komentar'] = $this->product_model->getTable('tbl_komentar_product', "id_product='$id'", "");
		$this->load->view('product/detail', $data);
	}

	function create_new()
	{
		$this->load->library('form_validation');
		$this->_validation();

		$config['upload_path']          = './img_product/';
    	$config['allowed_types']        = 'gif|jpg|png|jpeg';
    	$this->load->library('upload', $config);

		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('product/add_new');
		}
		else
		{
	    	if ( ! $this->upload->do_upload('gambar'))
		    {
		    	$error = array('error' => $this->upload->display_errors());
		    }
		    else
		    {
		    	$upload_data = $this->upload->data();
		    	$file_name = $upload_data['file_name'];
		    	$nama_file = str_replace(' ', '_', $_FILES['gambar']['name']);

		    	$request = array(
					'nama_product' 	=> $this->input->post('nama_product'),
					'description' 	=> $this->input->post('deskripsi_product'),
					'garansi' 		=> $this->input->post('garansi'),
					'cod' 			=> $this->input->post('cod'),
					'harga' 		=> $this->input->post('harga'),
					'gambar' 		=> $nama_file,
					'created_date' 	=> date('Y-m-d h:i:s')
				);
				$this->product_model->insert_data($request);
		    }

			$this->session->set_flashdata('message', 'Data berhasil disimpan.');
			redirect('product');
		}
	}

	function upvote_product($id_product)
	{
		$sql = $this->product_model->getCountVote($id_product);
		$row = $sql->row();
		$up_vote = $row->up_vote+1;

		$data = array(
			'up_vote' 	=> $up_vote
		);
		$this->product_model->update($id_product, $data);

		$this->session->set_flashdata('message', 'Vote berhasil ditambahkan.');
		redirect('product/detail/'.$id_product);
	}

	function downvote_product($id_product)
	{
		$sql = $this->product_model->getCountVote($id_product);
		$row = $sql->row();
		$down_vote = $row->down_vote+1;

		$data = array(
			'down_vote' => $down_vote
		);
		$this->product_model->update($id_product, $data);

		$this->session->set_flashdata('message', 'Vote berhasil ditambahkan.');
		redirect('product/detail/'.$id_product);
	}

	function simpan_komentar()
	{
		$id_product = $this->input->post('id_product');
		$nama = $this->input->post('nama');
		$komentar = $this->input->post('komentar');

		if($nama != "" && $komentar != "")
		{
			//simpan jika nama dan kometar diisi
			$request = array(
				'id_product' 	=> $id_product,
				'nama' 			=> $nama,
				'komentar' 		=> $komentar,
				'created_date' 	=> date('Y-m-d')
			);
			$this->product_model->insert_komentar($request);

			$this->session->set_flashdata('message', 'Komentar berhasil ditambahkan.');
			redirect('product/detail/'.$id_product);
		}
		else
		{
			$this->session->set_flashdata('message', 'Komentar gagal ditambahkan. Nama & Komentar Harus diisi.');
			redirect('product/detail/'.$id_product);
		}
	}

	function up_vote_komentar($id_komentar, $id_product)
	{
		$sql = $this->product_model->getCountVoteKomentar($id_komentar, $id_product);
		$row = $sql->row();
		$up_vote = $row->up_vote+1;

		$data = array(
			'up_vote' 	=> $up_vote
		);
		$this->product_model->update_komentar($data, $id_komentar, $id_product);

		$this->session->set_flashdata('message', 'Vote berhasil ditambahkan.');
		redirect('product/detail/'.$id_product);
	}

	function down_vote_komentar($id_komentar, $id_product)
	{
		$sql = $this->product_model->getCountVoteKomentar($id_komentar, $id_product);
		$row = $sql->row();
		$down_vote = $row->down_vote+1;

		$data = array(
			'down_vote' => $down_vote
		);
		$this->product_model->update_komentar($data, $id_komentar, $id_product);

		$this->session->set_flashdata('message', 'Vote berhasil ditambahkan.');
		redirect('product/detail/'.$id_product);
	}

	function _validation()
	{
		$this->form_validation->set_rules('nama_product', 'Nama Produk', 'trim|required');
		$this->form_validation->set_rules('deskripsi_product', 'Deskripsi', 'trim|required');
		$this->form_validation->set_rules('garansi', 'Garansi', 'trim|required');
		$this->form_validation->set_rules('cod', 'COD', 'trim|required');
		$this->form_validation->set_rules('harga', 'Harga', 'trim|required');
		$this->form_validation->set_error_delimiters(' <span style="color:#FF0000">', '</span>');
	}
}