<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php 
	$row = $sql->row();
	if($row->garansi == 1)
	{
		$garansi = "<i class='fa fa-check'></i>";
	}
	elseif($row->garansi == "2")
	{
		$garansi = "<i class='fa fa-times'></i>";
	}else
	{
		$garansi = "";
	}

	if($row->cod == 1)
	{
		$cod = "<i class='fa fa-check'></i>";
	}
	elseif($row->cod == "2")
	{
		$cod = "<i class='fa fa-times'></i>";
	}else
	{
		$cod = "";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Detail Product</title>
	<style type="text/css">
		.content{
			padding: 20px 30px;
		}
	</style>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/font_awesome5.3/css/all.min.css" rel="stylesheet" />
</head>
<body>
	<!-- Begin Navbar -->
	<nav class="navbar navbar-dark bg-primary">
	  <a class="navbar-brand" href="<?php echo site_url(); ?>">Fabelio</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavDropdown">
	    <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>product/create_new">Tambah Produk</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>">Daftar Produk</a>
	      </li>
	    </ul>
	  </div>
	</nav>
	<!-- End Navbar-->

	<div class="content">
		<div class="row">
			<div col class="col-lg-12 m-b-5">
				<?php if ($this->session->flashdata('message')) { ?>
				<div class="alert alert-success fade show">
				  <strong>Success!</strong>
				  <?php echo $this->session->flashdata('message'); ?>
				</div>
				<?php }?>
			</div>

			<div class="col-lg-8">
				<div class="jumbotron">
					<h1 class="display-5"><i class="fa fa-caret-right"></i> <?php echo $row->nama_product; ?> <i style="font-size: 10px;"><?php echo date('d/M/Y h:i:s', strtotime($row->created_date)); ?></i></h1>
					<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					  <ol class="carousel-indicators">
					    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
					    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
					    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
					  </ol>
					  <div class="carousel-inner">
					    <div class="carousel-item active">
					      <img src="<?php echo site_url(); ?>img_product/<?php echo $row->gambar; ?>" class="d-block w-100" alt="...">
					    </div>
					  </div>
					</div>
					<hr class="my-4">
					<p class="lead"><?php echo $row->description; ?></p>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card" style="width: 18rem;">
				  <ul class="list-group list-group-flush">
				    <li class="list-group-item">IDR <?php echo number_format($row->harga); ?></li>
				    <li class="list-group-item">Garansi <?php echo $garansi; ?></li>
				    <li class="list-group-item">COD <?php echo $cod; ?></li>
				  </ul>
				  <div class="card-body">
				    <a href="<?php echo site_url(); ?>product/upvote_product/<?php echo $row->id_product; ?>" class="card-link"><?php echo $row->up_vote; ?> <i class="fa fa fa-thumbs-up"></i> </a>
				    <a href="<?php echo site_url(); ?>product/downvote_product/<?php echo $row->id_product; ?>" class="card-link"><?php echo $row->down_vote; ?> <i class="fa fa fa-thumbs-down"></i></a>
				  </div>
				</div>
			</div>
		</div>

		<div class="col-lg-12" id="kometar">
			<h4>
				<i class="fa fa-chevron-right"></i> Komentar Tentang Produk Ini 
				<a href="javascript:void(0)" onclick="showModalKomentar('<?php echo $row->id_product ?>')" class="btn btn-primary btn-sm">
					<i class="fa fa-plus"></i> Tambah Komentar
				</a>
			</h4>
			<hr class="my-4">
			<?php
				foreach ($sql_komentar->result() as $row_k) {
			?>
				<div class="media">
				  <img src="<?php echo site_url(); ?>assets/user_image.png" class="mr-3" alt="..." width="50">
				  <div class="media-body">
				    <h5 class="mt-0"><?php echo $row_k->nama; ?> <small><i><?php echo date('d/M/Y h:i:s', strtotime($row_k->created_date)); ?></i></small> <a href="<?php echo site_url(); ?>product/down_vote_komentar/<?php echo $row_k->id_komentar; ?>/<?php echo $row->id_product ?>"><i class="fa fa-reply"></i></a></h5>
				    <?php echo $row_k->komentar; ?>
				  	<br>
				  	<a href="<?php echo site_url(); ?>product/up_vote_komentar/<?php echo $row_k->id_komentar; ?>/<?php echo $row->id_product ?>"><?php echo $row_k->up_vote; ?> <i class="fa fa-thumbs-up"></i></a> &nbsp;&nbsp;&nbsp;
				  	<a href="<?php echo site_url(); ?>product/down_vote_komentar/<?php echo $row_k->id_komentar; ?>/<?php echo $row->id_product ?>"><?php echo $row_k->down_vote; ?> <i class="fa fa-thumbs-down"></i></a>
				  </div>
				</div>
			<?php
				}
			?>
		</div>
	</div>

	<!-- Modal Komentar -->
	<div class="modal fade" id="modalKomentar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus"></i> Form Tambah Komentar</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        <form method="post" action="<?php echo site_url(); ?>product/simpan_komentar">
	        	<input type="hidden" name="id_product" id="id_product">
	        	<div class="form-group">
					<label for="nama">Nama :</label>
					<input type="text" name="nama" id="nama" class="form-control" placeholder="ketikan nama anda">
				</div>
	        	<div class="form-group">
					<label for="komentar">Komentar :</label>
					<textarea class="form-control" name="komentar"></textarea>
				</div>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Submit Komentar</button>
	      </div>
	      </form>
	    </div>
	  </div>
	</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="<?php echo site_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript">
	function showModalKomentar(id_product)
	{
		document.getElementById('id_product').value = id_product
		$('#modalKomentar').modal('show');
	}
</script>

</body>
</html>